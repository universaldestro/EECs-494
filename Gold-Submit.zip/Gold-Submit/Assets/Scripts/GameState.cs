using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class GameState : MonoBehaviour
{
    public Text Message;    // Reference to the UI Text element
    public float displayTime = 5f; // Time to display the message
    public Text levelText;
    public float displayDuration = 5f;
    public float fadeDuration = 1f;

    private void Start()
    {
        // Ensure the lose message is initially hidden
        int currentLevel = PlayerPrefs.GetInt("PlayerLevel", SceneManager.GetActiveScene().buildIndex);
        StartCoroutine(DisplayLevel(currentLevel));
        Message.enabled = false;
    }
    private IEnumerator DisplayLevel(int level)
    {
        levelText.text = "Level " + level + "\nPress SHIFT \n to Change Gun";
        levelText.canvasRenderer.SetAlpha(1f); // Ensure text is fully visible initially

        // Freeze the game
        Time.timeScale = 0f;

        // Yield while waiting in real-time (not affected by time scale)
        yield return new WaitForSecondsRealtime(displayDuration);

        float elapsedTime = 0f;
        while (elapsedTime < fadeDuration)
        {
            elapsedTime += Time.unscaledDeltaTime; // Use unscaled delta time since game is frozen
            float alpha = Mathf.Lerp(1f, 0f, elapsedTime / fadeDuration);
            levelText.canvasRenderer.SetAlpha(alpha);
            yield return null;  // Continue to next frame
        }

        levelText.canvasRenderer.SetAlpha(0f); // Ensure text is fully invisible at the end

        // Unfreeze the game
        Time.timeScale = 1f;
    }
    // Call this function when the player loses
    public void TriggerGameOver(bool won)
    {

        if (won)
        {


            Message.text = "YOU WIN!";
        }
        else {
            Message.text = "YOU LOSE!";
        }
        StartCoroutine(GameOverSequence());
    }

    private IEnumerator GameOverSequence()
    {
        // Enable the "You Lose" message
        Message.enabled = true;

        // Freeze the game
        Time.timeScale = 0f;

        // Wait for a certain amount of real-time (not affected by time scale)
        yield return new WaitForSecondsRealtime(displayTime);

        // Disable the "You Lose" message
        Message.enabled = false;

        // Unfreeze the game
        Time.timeScale = 1f;

        // Trigger any additional game over logic here (e.g., reload scene, show menu, etc.)
    }
}