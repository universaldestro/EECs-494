using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;




public abstract class Health : MonoBehaviour
{
    public char characterType; 
    public int health;
    // Start is called before the first frame update

    protected void TakeDamage() {

        health -= 1;
        if (health == 0) {
            Death();
        }
    }

    public void Heal() {
        if (health < 5) {

            health += 1; }
    }
    public void Death() {
         GameState gameOverController = FindObjectOfType<GameState>();
                   
        if (GameObject.FindGameObjectWithTag("outlaw").GetComponent<Health>().health < 1  )
        {

            gameOverController.TriggerGameOver(true);
            if (SceneManager.GetActiveScene().buildIndex < 4) {
                SceneManager.LoadScene(0);
            }
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
            
        }
        
        else
        {
            gameOverController.TriggerGameOver(false);
            SceneManager.LoadScene(0);
        }
        //Program death maybe animation
        

    }


   public void processDamage(){
        TakeDamage();
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("botBullet") && characterType == 'p') {
            processDamage();
        }
        else if (collision.gameObject.CompareTag("playerBullet") && characterType == 'b') {
            processDamage();
        }
        else if (collision.gameObject.CompareTag("pickup")) {
            Heal();
        }
    }

    // Update is called once per framei

}
