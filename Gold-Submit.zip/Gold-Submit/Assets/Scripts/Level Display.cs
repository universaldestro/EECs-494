using System.Collections;
using UnityEngine;
using UnityEngine.UI; 
using UnityEngine.SceneManagement;


public class LevelDisplay : MonoBehaviour
{
    public Text levelText; 
    public float displayDuration = 5f; 
    public float fadeDuration = 1f; 

    private void Start()
    {
       
        int currentLevel = PlayerPrefs.GetInt("PlayerLevel", SceneManager.GetActiveScene().buildIndex); 
        StartCoroutine(DisplayLevel(currentLevel));
    }

    private IEnumerator DisplayLevel(int level)
    {
        levelText.text = "Level " + level;
        levelText.canvasRenderer.SetAlpha(1f); // Ensure text is fully visible initially

        // Freeze the game
        Time.timeScale = 0f;

        // Yield while waiting in real-time (not affected by time scale)
        yield return new WaitForSecondsRealtime(displayDuration);

        float elapsedTime = 0f;
        while (elapsedTime < fadeDuration)
        {
            elapsedTime += Time.unscaledDeltaTime; // Use unscaled delta time since game is frozen
            float alpha = Mathf.Lerp(1f, 0f, elapsedTime / fadeDuration);
            levelText.canvasRenderer.SetAlpha(alpha);
            yield return null;  // Continue to next frame
        }

        levelText.canvasRenderer.SetAlpha(0f); // Ensure text is fully invisible at the end

        // Unfreeze the game
        Time.timeScale = 1f;
    }
}