public class MyTestScriptNoMonoBehaviour
{
    public int level;
}