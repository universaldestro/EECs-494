using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OutlawController_lvl2 : Health
{
    public Transform player;          // Reference to the player character
    public Transform soaker;          // Reference to the enemy's gun
    public GameObject bubblePrefab;   // Bubble prefab to instantiate
    public float fireRate = 1.0f;     // How often the enemy shoots
    public float bubbleSpeed = 7f;    // Speed of the enemy's bubbles
    public float verticalMoveSpeed = 1f;  // Speed of the vertical movement
    public float verticalMoveDistance = 2f;  // Distance to move up and down
    public float oscillationAmplitude = 1.0f; // Amplitude for oscillation in shooting
    public float oscillationFrequency = 2.0f; // Frequency for oscillation in shooting

    private float nextFireTime = 0f;  // Timer to control fire rate
    private Vector3 initialPosition;  // Initial position to calculate vertical movement
    private bool movingUp = true;     // Direction of vertical movement

    private void Start()
    {
        health = 5;
        characterType = 'b';
        initialPosition = transform.position;
    }

    void Update()
    {
        HandleShooting();
        HandleVerticalMovement();
    }

    // Handle enemy shooting logic
    void HandleShooting()
    {
        // If the current time is past the next allowed fire time
        if (Time.time >= nextFireTime)
        {
            nextFireTime = Time.time + fireRate; // Set next fire time
            ShootAtPlayer();
        }
    }

    // Instantiate and shoot a bubble towards the player
    void ShootAtPlayer()
    {
        // Calculate the oscillation based on time
        float oscillationOffset = Mathf.Sin(Time.time * oscillationFrequency) * oscillationAmplitude;

        // Create the bubble at the soaker's position
        GameObject bubble = Instantiate(bubblePrefab, soaker.position, soaker.rotation);
        Physics2D.IgnoreCollision(bubble.GetComponent<Collider2D>(), GetComponent<Collider2D>());
        Physics2D.IgnoreCollision(GetComponent<Collider2D>(), bubble.GetComponent<Collider2D>());

        // Get the BubbleController script and initialize it with the direction
        BubbleController bubbleController = bubble.GetComponent<BubbleController>();
        Vector3 shootingDirection = (player.position - soaker.position).normalized;

        // Apply the oscillation to the shooting direction
        shootingDirection.x += oscillationOffset;

        bubbleController.Initialize(shootingDirection.normalized);
        bubbleController.speed = bubbleSpeed;
    }

    // Handle vertical movement logic
    void HandleVerticalMovement()
    {
        Vector3 targetPosition = initialPosition + (movingUp ? Vector3.up : Vector3.down) * verticalMoveDistance;

        // Move towards the target position
        transform.position = Vector3.MoveTowards(transform.position, targetPosition, verticalMoveSpeed * Time.deltaTime);

        // Check if we have reached the target position
        if (transform.position == targetPosition)
        {
            movingUp = !movingUp; // Reverse direction
        }
    }
}