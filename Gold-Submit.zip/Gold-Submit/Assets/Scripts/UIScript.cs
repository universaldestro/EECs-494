using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
public class UIScript : MonoBehaviour
{

    public Image[] hearts;
    public Sprite fullHeart, emptyHeart;
    public GameObject obj;
    //public TextMeshProUGUI text;
    //public string message;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {

        //text.text = message + obj.GetComponent<Health>().health.ToString();

        for (int i = 0; i < hearts.Length; i++)
        {
            if (i < obj.GetComponent<Health>().health)
            {
                hearts[i].enabled = true;
            }
            else {
                hearts[i].enabled = false;
            }
        }
    }
}
