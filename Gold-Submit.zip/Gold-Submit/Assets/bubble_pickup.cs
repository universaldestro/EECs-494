using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bubble_pickup : MonoBehaviour
{
    private PlayerController player;
    private void OnCollisionEnter2D(Collision2D collision)
    {

        player  = FindAnyObjectByType<PlayerController>();
        if (collision.gameObject.CompareTag("playerBullet")){

            player.Heal();
            Destroy(this.gameObject);
        }
        if ( collision.gameObject.CompareTag("player"))
        {

             player.Heal();
            Destroy(this.gameObject);
        }
    }
}
