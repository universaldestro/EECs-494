using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boomerang : MonoBehaviour
{
    public float throwSpeed = 5f;
    public float returnSpeed = 7f;
    public float maxDistance = 5f;
    public float rotationSpeed = 300f;
    public float rotationSoundInterval = 0.2f;
    private bool returning = false;
    private Transform playerTransform;
    private Vector3 throwDirection;
    private Vector3 startPosition;
    Inventory inv;

    public AudioClip rotationSoundClip;
    private AudioSource audioSource;

    private float timeSinceLastRotationSound;

    void Start()
    {
        startPosition = transform.position;
    }

    void Update()
    {
        if (!returning)
        {
            transform.position += throwDirection * throwSpeed * Time.deltaTime;

            if (Vector3.Distance(startPosition, transform.position) >= maxDistance)
            {
                returning = true;
            }
        }
        else
        {
            Vector3 returnDirection = (playerTransform.position - transform.position).normalized;
            transform.position += returnDirection * returnSpeed * Time.deltaTime;

            if (Vector3.Distance(transform.position, playerTransform.position) < 0.2f)
            {
                Destroy(gameObject);
            }
        }
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("enemy"))
        {
            Movement enemy = other.GetComponent<Movement>();
            if (enemy != null)
            {
                if (enemy.canBeKilledByBoomerang)
                {
                    enemy.TakeDamage(1, 'n');
                }
                else if (enemy.canBeStunned)
                {
                    enemy.StunEnemy();
                }
            }
        }

        if (other.CompareTag("key") || other.CompareTag("bomb") || other.CompareTag("rupee") || other.CompareTag("rupee5") || other.CompareTag("heart"))
        {
            CollectItem(other.gameObject);
        }
    }


    void CollectItem(GameObject item)
    {
        if (item.CompareTag("key"))
        {
            inv.AddKeys(1);
        }
        else if (item.CompareTag("bomb"))
        {
            inv.AddBombs(1);
        }
        else if (item.CompareTag("rupee"))
        {
            inv.AddRupees(1);
        }
        else if (item.CompareTag("rupee5"))
        {
            inv.AddRupees(5);
        }
        else if (item.CompareTag("heart"))
        {
            inv.AddHearts(1);
        }

        Destroy(item);
    }

    public void Initialize(Vector2 direction, Transform player, Inventory playerInventory)
    {
        throwDirection = direction;
        playerTransform = player;
        inv = playerInventory;
        startPosition = transform.position;
    }

}