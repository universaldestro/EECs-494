using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CheatCode : MonoBehaviour
{
    bool cheat_code = false;
    public Inventory inv;


    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Alpha4))
        {
          GameObject.FindGameObjectWithTag("Player").transform.position = new Vector3(87.5f,48,0.1f);;
          GameObject.FindGameObjectWithTag("MainCamera").transform.position = new Vector3(87.5f, 51, -10);;
         //teleport
        }


        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            cheat_code = !cheat_code;
            //GetComponent<WeaponDisplayer>().ToggleCheatMode();

            if (cheat_code)
            {
                inv.CheatResources();
                inv.godmode = true;
                Debug.Log("Cheated!");
            } else
            {
                inv.ResetResources();
                inv.godmode = false;
            }
        }
    }
}
