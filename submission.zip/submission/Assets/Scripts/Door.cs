using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Door : MonoBehaviour
{
    public enum DoorType { TopLeft, TopRight, Right, Left }
    public DoorType doorType;
}
