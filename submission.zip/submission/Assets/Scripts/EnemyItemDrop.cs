using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyItemDrop : MonoBehaviour
{
    public GameObject rupee1Prefab, rupee5Prefab, heartPrefab, bombPrefab, keyPrefab;

    public float rupee1DropRate;
    public float rupee5DropRate;
    public float heartDropRate;
    public float bombDropRate;
    public float keyDropRate;
    public float noDropRate;

    public void DropItem()
    {
        float randomRoll = Random.Range(0f, 100f);
        float cumulativeProbability = noDropRate;

        // nothing dropped
        if (randomRoll <= noDropRate) return;

        cumulativeProbability += rupee1DropRate;
        if (randomRoll <= cumulativeProbability)
        {
            Instantiate(rupee1Prefab, transform.position, Quaternion.identity);
            return;
        }

        cumulativeProbability += rupee5DropRate;
        if (randomRoll <= cumulativeProbability)
        {
            Instantiate(rupee5Prefab, transform.position, Quaternion.identity);
            return;
        }

        cumulativeProbability += heartDropRate;
        if (randomRoll <= cumulativeProbability)
        {
            Instantiate(heartPrefab, transform.position, Quaternion.identity);
            return;
        }

        cumulativeProbability += bombDropRate;
        if (randomRoll <= cumulativeProbability)
        {
            Instantiate(bombPrefab, transform.position, Quaternion.identity);
            return;
        }

        cumulativeProbability += keyDropRate;
        if (randomRoll <= cumulativeProbability)
        {
            Instantiate(keyPrefab, transform.position, Quaternion.identity);
            return;
        }
    }
}
