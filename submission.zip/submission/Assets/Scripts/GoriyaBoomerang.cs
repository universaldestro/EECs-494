using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoriyaBoomerang : MonoBehaviour
{
    public float throwSpeed = 5f;
    public float returnSpeed = 7f;
    public float maxDistance = 5f;
    private bool returning = false;
    private Transform goriyaTransform;
    private Vector3 throwDirection;
    private Vector3 startPosition;
    private Transform playerTransform;
    public float rotationSpeed = 300f;
    public float rotationSoundInterval = 0.2f;
    public AudioClip rotationSoundClip;
    private AudioSource audioSource;

    private float timeSinceLastRotationSound;


    public void Initialize(Vector3 direction, Transform goriya, Transform player)
    {
        throwDirection = direction;
        goriyaTransform = goriya;
        playerTransform = player;
        startPosition = transform.position;

        audioSource = GetComponent<AudioSource>();
        timeSinceLastRotationSound = 0f;
    }

    void Update()
    {
        RotateBoomerang();

        if (!returning)
        {
            transform.position += throwDirection * throwSpeed * Time.deltaTime;

            if (Vector3.Distance(startPosition, transform.position) >= maxDistance)
            {
                returning = true;
            }
        }
        else
        {
            Vector3 returnDirection = (goriyaTransform.position - transform.position).normalized;
            transform.position += returnDirection * returnSpeed * Time.deltaTime;

            if (Vector3.Distance(transform.position, goriyaTransform.position) < 0.2f)
            {
                Destroy(gameObject);
            }
        }
    }

    private void RotateBoomerang()
    {
        transform.Rotate(0, 0, rotationSpeed * Time.deltaTime);

        timeSinceLastRotationSound += Time.deltaTime;
        if (timeSinceLastRotationSound >= rotationSoundInterval)
        {
            PlayRotationSound();
            timeSinceLastRotationSound = 0f;
        }
    }

    private void PlayRotationSound()
    {
        if (rotationSoundClip != null && audioSource != null)
        {
            audioSource.PlayOneShot(rotationSoundClip);
        }
    }

    void OnTriggerEnter(Collider other)
    {
        if (!returning && other.CompareTag("Player"))
        {
            HasHealth playerHealth = other.GetComponent<HasHealth>();
            if (playerHealth != null)
            {
                playerHealth.TakeDamage('n');
                returning = true;
            }
        }
    }
}
