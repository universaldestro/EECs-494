using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Inventory : MonoBehaviour
{
    int rupee_count = 0;
    int keys_count = 0;
    int bombs_count = 0;
    int hearts_count = 0;

    int temp_rupee_count = 0;
    int temp_keys_count = 0;
    int temp_bombs_count = 0;
    int temp_hearts_count = 0;

    // for cheat code
    int maxRupees = 99;
    int maxKeys = 5;
    int maxBombs = 10;
    public int maxHearts = 6;
    public bool godmode = false;

    private void Start()
    {
        hearts_count = maxHearts;
    }
    public void AddRupees(int num_rupees)
    {
        rupee_count += num_rupees;
        if (num_rupees > 0) temp_rupee_count += num_rupees;
    }

    public int GetRupees()
    {
        return rupee_count;
    }

    public void AddKeys(int num_keys)
    {
        keys_count += num_keys;
        if (num_keys > 0) temp_keys_count += num_keys;
    }

    public int GetKeys()
    {
        return keys_count;
    }

    public void AddBombs(int num_bombs)
    {
        bombs_count += num_bombs;
        if (num_bombs > 0) temp_bombs_count += num_bombs;
    }

    public int GetBombs()
    {
        return bombs_count;
    }

    public void AddHearts(int num_hearts)
    {
        Debug.Log("Added: ");
        Debug.Log(num_hearts);
        if (hearts_count < maxHearts || num_hearts < 0) { 
            hearts_count += num_hearts;
            if(num_hearts > 0) temp_hearts_count += num_hearts;
        }
        
    }

    public int GetHearts()
    {
        return hearts_count;
    }

    public void CheatResources()
    {
        temp_rupee_count = rupee_count;
        temp_keys_count = keys_count;
        temp_bombs_count = bombs_count;
        temp_hearts_count = hearts_count;

        rupee_count = maxRupees;
        keys_count = maxKeys;
        bombs_count = maxBombs;
        hearts_count = maxHearts;
        godmode = true;
    }

    public void ResetResources()
    {
        rupee_count = temp_rupee_count;
        keys_count = temp_keys_count;
        bombs_count = temp_bombs_count;
        hearts_count = temp_hearts_count;
        godmode = false;
    }
}
