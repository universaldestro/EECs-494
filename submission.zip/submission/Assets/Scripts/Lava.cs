using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Lava : MonoBehaviour
{
    public Sprite walkableBlockSprite;
    private bool isWalkable = false;

    public void Extinguish()
    {
        if (!isWalkable)
        {
            GetComponent<SpriteRenderer>().sprite = walkableBlockSprite;

            gameObject.tag = "walkableBlock";

            isWalkable = true;
        }
    }
}
