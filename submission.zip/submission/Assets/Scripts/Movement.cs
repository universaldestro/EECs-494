using UnityEngine;
using System.Collections;

public abstract class Movement : MonoBehaviour
{
    // This method should be overridden by all derived classes
    public bool canMove =false;
    public int health;
    public char direction;
    public RoomEventKey parentEvent = null;
    public RoomEventDoor parentEvent2 = null;
    private bool killed = false;
    public bool isStunned = false;
    public float stunDuration = 2.0f;
    public abstract void Move();
    public AudioClip defeatSoundClip;
    protected bool drops = false;
    public bool canBeStunned = false;
    public bool canBeKilledByBoomerang = false;


    public virtual void TakeDamage(int amount, char direction)
    {
        health -= amount;
        AudioSource.PlayClipAtPoint(defeatSoundClip, transform.position, 1);
        //newKnockback(direction);
        if (health <= 0)
        {
            if (parentEvent != null && !killed) {
                killed = true;
                parentEvent.numChildren -= 1;
                
               
            }
            if (parentEvent2 != null && !killed) {
                killed = true;
                parentEvent.numChildren -= 1;
            }
            if (drops) {
                GetComponent<EnemyItemDrop>().DropItem();
            }
            Destroy(gameObject);
        }
    }

    public void StunEnemy()
    {
        if (canBeStunned)
        {
            isStunned = true;
            stunDuration = 2.0f;
            canMove = false;
            StartCoroutine(UnstunAfterDuration(stunDuration));
        }
    }

    protected IEnumerator UnstunAfterDuration(float duration)
    {
        yield return new WaitForSeconds(duration);
        isStunned = false;
        canMove = true;
    }

    protected void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("boomerang"))
        {
            StunEnemy();
            if (canBeKilledByBoomerang && health > 0)
            {
                TakeDamage(1, 'k');
            }
        } else if (health > 0)
        {
            TakeDamage(1, 'k');
        }
    }

}