using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RoomTextEvent : MonoBehaviour
{
    public GameObject TextPrefab;
    public ArrowKeyMovement player;
    public bool done = false;
    private GameObject textObject;
    
    // Update is called once per frame
    void Update()
    {
        if (player.currentRoom == gameObject.name && !done)
        {
           textObject =  Instantiate(TextPrefab);
            done = true;
        }
        else if(textObject != null && done && player.currentRoom != gameObject.name) {
            Destroy(textObject);
            done = false;
            Debug.Log("Deleting constantly");
        }
    }

}
