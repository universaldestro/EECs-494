using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class TypewriterEffect : MonoBehaviour
{
    public Text messageText; // Reference to the Text component
    public string message = "The secret level is in the Eastern Peninsula"; // The message to display
    public float typingSpeed = 0.05f; // Time between each character is typed
    
    void Start()
    {
        StartCoroutine(TypeMessage());
    }

    private IEnumerator TypeMessage()
    {
        // Clear the text initially
        messageText.text = "";

        // Loop through each character in the message string
        foreach (char letter in message.ToCharArray())
        {
            // Add the character to the text
            messageText.text += letter;

            // Wait for the specified typing speed time before continuing the loop
            yield return new WaitForSeconds(typingSpeed);
        }
        
    }
}