using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WaterDrop : MonoBehaviour
{
    public float speed = 100f;
    private Vector3 direction;
    public AudioClip waterattackclip;

    public void SetDirection(Vector3 moveDirection)
    {
        direction = moveDirection;
    }

    void Start()
    {
        //Destroy(gameObject, 2f);
    }

    void Update()
    {
        transform.position += direction * speed * Time.deltaTime;
    }

    private void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.CompareTag("lava"))
        {
            Lava lavaBlock = other.gameObject.GetComponent<Lava>();
            if (lavaBlock != null)
            {
                lavaBlock.Extinguish();
            }

            Destroy(gameObject);
        }

        if (other.gameObject.CompareTag("WALL"))
        {
            Destroy(gameObject);
        }

        if (other.gameObject.CompareTag("enemy"))
        {
            Movement enemy = other.gameObject.GetComponent<Movement>();

            enemy.TakeDamage(1, 'n');
            AudioSource.PlayClipAtPoint(waterattackclip, transform.position, 1);
        }
    }
}
