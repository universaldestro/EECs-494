using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class WeaponDisplayer : MonoBehaviour
{
    public ArrowKeyMovement playerMovement;
    TextMeshProUGUI text_component;
    public bool cheatMode = false;
    public Inventory inv;

    // Start is called before the first frame update
    void Start()
    {
        text_component = GetComponent<TextMeshProUGUI>();
    }

    // Update is called once per frame
    void Update()
    {
        cheatMode = inv.godmode;
        if (text_component != null)
        {
            string currentWeapon = GetWeaponName(playerMovement.currentWeapon);
            string cheatModeStatus = cheatMode ? "Cheat Mode: On" : "Cheat Mode: Off";

            string displayText = "\nWeapon (X): Sword" +
                                 "\nWeapon (Z): " + currentWeapon +
                                 "\nSwitch Weapon (Space)" + 
                                 "\n" + cheatModeStatus;
            text_component.text = displayText;
        }

    }

    string GetWeaponName(WeaponType weapon)
    {
        switch (weapon)
        {
            case WeaponType.Bow:
                return "Bow";
            case WeaponType.Bomb:
                return "Bomb";
            case WeaponType.WaterGun:
                return "WaterGun";
            case WeaponType.Boomerang:
                return "Boomerang";
            default:
                return "No Weapon";
        }
    }
}
